//memuat express,router, dan konfigurasi database mysql
var express = require('express');
var router = express.Router();
const mysql = require('mysql');
//memuat library database
var connection = require('../library/database');


/**
 * Menampikan halaman daftar soal 
 */
router.get('/', function (req, res, next) {
    //query database
    connection.query('SELECT * FROM soal ORDER BY id desc', function (err, rows) {
        if (err) {
            req.flash('error', err);
            res.render('soal', {
                data: ''
            });
        } else {
           
            
            res.render('soal/index', {
                data: rows 
            });
        }
    });
});

/**
 * MEMBUAT SOAL BARU
 */
router.get('/create', function (req, res, next) {
    res.render('soal/create', {
        pertanyaan: '',
        jawaban_a: '',
        jawaban_b: '',
        jawaban_c: '',
        jawaban_d: '',
        kesulitan: '',
        materi: ''
    })
})

/**
 * Fungsi menyimpan soal yang telah dibuat
 */
router.post('/store', function (req, res, next) {
    

    let pertanyaan   = req.body.pertanyaan;
    let jawaban_a = req.body.jawaban_a;
    let jawaban_b = req.body.jawaban_b;
    let jawaban_c = req.body.jawaban_c;
    let jawaban_d = req.body.jawaban_d;
    let kesulitan = req.body.kesulitan;
    let materi = req.body.materi;
    let errors  = false;

    if(!errors) {

        let formData = {
            pertanyaan: pertanyaan,
            jawaban_a: jawaban_a,
            jawaban_b: jawaban_b,
            jawaban_c: jawaban_c,
            jawaban_d: jawaban_d,
            kesulitan: kesulitan,
            materi: materi
        }
        
        // insert query
        connection.query('INSERT INTO soal SET ?', formData, function(err, result) {
            
            if (err) {
                req.flash('error', err)
                 
                // render to add.ejs
                res.render('soal/create', {
                    pertanyaan: formData.pertanyaan,
                    jawaban_a: formData.jawaban_a,                    
                    jawaban_b: formData.jawaban_b,                    
                    jawaban_c: formData.jawaban_c,                    
                    jawaban_d: formData.jawaban_d,                    
                    kesulitan: formData.kesulitan,                   
                    materi: formData.materi                   
                })
            } else {                
                req.flash('success', 'Data Berhasil Disimpan!');
                res.redirect('/soal');
            }
        })
    }

})

/**
 * Edit soal
 */
router.get('/edit/(:id)', function(req, res, next) {

    let id = req.params.id;
   
    connection.query('SELECT * FROM soal WHERE id = ' + id, function(err, rows, fields) {
        if(err) throw err
         
        // if user not found
        if (rows.length <= 0) {
            req.flash('error', 'Data soal Dengan ID ' + id + " Tidak Ditemukan")
            res.redirect('/soal')
        }
        // if book found
        else {
            // render to edit.ejs
            res.render('soal/edit', {
                id:      rows[0].id,
                pertanyaan:   rows[0].pertanyaan,
                jawaban_a: rows[0].jawaban_a,
                jawaban_b: rows[0].jawaban_b,
                jawaban_c: rows[0].jawaban_c,
                jawaban_d: rows[0].jawaban_d,
                kesulitan: rows[0].kesulitan,
                materi: rows[0].materi
            })
        }
    })
})

/**
 * Update soal
 */
router.post('/update/:id', function(req, res, next) {

    let id      = req.params.id;
    let pertanyaan   = req.body.pertanyaan;
    let jawaban_a = req.body.jawaban_a;
    let jawaban_b = req.body.jawaban_b;
    let jawaban_c = req.body.jawaban_c;
    let jawaban_d = req.body.jawaban_d;
    let kesulitan = req.body.kesulitan;
    let materi = req.body.materi;
    let errors  = false;

    if( !errors ) {   
 
        let formData = {
            pertanyaan: pertanyaan,
            jawaban_a: jawaban_a,
            jawaban_b: jawaban_b,
            jawaban_c: jawaban_c,
            jawaban_d: jawaban_d,
            kesulitan: kesulitan,
            materi: materi
        }

   
        connection.query('UPDATE soal SET ? WHERE id = ' + id, formData, function(err, result) {
            
            if (err) {
                // 
                req.flash('error', err)
                // render to edit.ejs
                res.render('soal/edit', {
                    id:     req.params.id,
                    name:   formData.name,
                    author: formData.author
                })
            } else {
                req.flash('success', 'Data Berhasil Diupdate!');
                res.redirect('/soal');
            }
        })
    }
})

/**
 * Hapus soal
 */
router.get('/delete/(:id)', function(req, res, next) {

    let id = req.params.id;
     
    connection.query('DELETE FROM soal WHERE id = ' + id, function(err, result) {
        
        if (err) {
            // 
            req.flash('error', err)
            
            res.redirect('/soal')
        } else {
            // 
            req.flash('success', 'Data Berhasil Dihapus!')
            
            res.redirect('/soal')
        }
    })
})
router.delete('/delete/(:id)', function(req, res, next) {

    let id = req.params.id;
     
    connection.query('DELETE FROM soal WHERE id = ' + id, function(err, result) {
     
        if (err) {
            // 
            req.flash('error', err)
            
            res.redirect('/soal')
        } else {
            // 
            req.flash('success', 'Data Berhasil Dihapus!')
            
            res.redirect('/soal')
        }
    })
})

/**
 * Pembuatan paket soal 
 */
router.get('/paketsoal', function (req, res, next) {
   
    //render ke view posts index
    res.render('soal/paketsoal');
});

/**
 * Pembuatan paket soal secara acak
 */
router.get('/acak', function (req, res, next) {
    //query
    connection.query('SELECT * FROM soal ORDER BY RAND() LIMIT 20', function (err, rows) {
        if (err) {
            req.flash('error', err);
            res.render('soal', {
                data: ''
            });
        } else {
            //render ke view acak index
            res.render('soal/acak', {
                data: rows 
            });
        }
    });
});

/**
 * Pembuatan paket soal berdasarkan tingkat kesulitan
 */
router.get('/kesulitan', function (req, res, next) {
    //query
    connection.query("SELECT * FROM (SELECT * FROM `soal` WHERE kesulitan = 'Mudah' ORDER BY RAND() LIMIT 5) AS mudah UNION ALL SELECT * FROM (SELECT * FROM `soal` WHERE kesulitan = 'Sedang' ORDER BY RAND() LIMIT 10) AS sedang UNION ALL SELECT * FROM (SELECT * FROM `soal` WHERE kesulitan = 'Sulit' ORDER BY RAND() LIMIT 5) AS sulit", function (err, rows) {
        if (err) {
            req.flash('error', err);
            res.render('soal', {
                data: ''
            });
        } else {
            //render ke view kesulitan index
            res.render('soal/kesulitan', {
                data: rows // <-- data posts
            });
        }
    });
});

/**
 * Pembuatan paket soal bedasarkan kriteria kusus
 */
router.get('/khusus', function (req, res, next) {
    //query
    connection.query("SELECT * FROM (SELECT * FROM `soal` WHERE materi = 'Bab 1' ORDER BY RAND() LIMIT 2) AS bab1 UNION ALL SELECT * FROM (SELECT * FROM `soal` WHERE materi = 'Bab 2' ORDER BY RAND() LIMIT 3) AS bab2 UNION ALL SELECT * FROM (SELECT * FROM `soal` WHERE materi = 'Bab 3' ORDER BY RAND() LIMIT 10) AS bab3 UNION ALL SELECT * FROM (SELECT * FROM `soal` WHERE materi = 'Bab 4' ORDER BY RAND() LIMIT 3) AS bab4 UNION ALL SELECT * FROM (SELECT * FROM `soal` WHERE materi = 'Bab 5' ORDER BY RAND() LIMIT 2) AS bab5", function (err, rows) {
        if (err) {
            req.flash('error', err);
            res.render('soal', {
                data: ''
            });
        } else {
            //render ke view materi index
            res.render('soal/khusus', {
                data: rows // 
            });
        }
    });
});



module.exports = router;